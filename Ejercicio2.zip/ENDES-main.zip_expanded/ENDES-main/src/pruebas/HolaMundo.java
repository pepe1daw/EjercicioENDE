package pruebas;

public class HolaMundo {

	public static void main(String[] args) {
		System.out.println("Hola GiT!!"); //ESTE ARCHIVO HACE QUE EN LA CONSOLA, CUANDO SE EJECUTE EL CODIGO, NOS APAREZCA EL MENSAJE HOLA GIT.
	}

}
